# лего

A Pen created on CodePen.

Original URL: [https://codepen.io/zbazfpsn-the-animator/pen/RNPZMqb](https://codepen.io/zbazfpsn-the-animator/pen/RNPZMqb).

